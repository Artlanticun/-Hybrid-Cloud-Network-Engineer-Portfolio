# Docs

Lab notes, configurations, future project ideas.
