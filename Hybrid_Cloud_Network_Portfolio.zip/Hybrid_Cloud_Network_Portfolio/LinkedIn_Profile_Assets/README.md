# LinkedIn Profile Assets

Screenshots, resume, and certification progress.
