# FreePBX VoIP Azure

Install and configure FreePBX in Azure with Zoiper.
