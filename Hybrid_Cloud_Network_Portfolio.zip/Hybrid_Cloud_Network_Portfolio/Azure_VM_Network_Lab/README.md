# Azure VM Network Lab

Lab to deploy Azure VMs, subnets, and NSG rules.
